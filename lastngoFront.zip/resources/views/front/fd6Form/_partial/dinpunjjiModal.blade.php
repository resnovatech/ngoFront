<!--modal-->
<div class="modal modal-xl fade" id="Dinpunjji"  aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">

                    সংলগ্নী ‘’ছ’’ এর বিবরণ

                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="card">
                    <div class="card-body">


                            <div class="row">


                                    <div class="col-lg-12 mb-3">
                                        <label for="" class="form-label">শিরোনাম/বিষয়<span class="text-danger">*</span></label>
                                        <input type="text"  name="subject" class="form-control" id="subject0"
                                        placeholder="" >
                                    </div>


                                    <div class="col-lg-6 mb-3">
                                        <label for="" class="form-label">তারিখ<span class="text-danger">*</span></label>
                                        <input type="text"  name="seminer_date" class="form-control datepickerOne" id="seminer_date0"
                                        placeholder="" >
                                    </div>

                                    <div class="col-lg-6 mb-3">
                                        <label for="" class="form-label">সময়<span class="text-danger">*</span></label>
                                        <input type="text"  name="seminer_time" class="form-control" id="seminer_time0"
                                        placeholder="" >
                                    </div>

                                    <div class="col-lg-6 mb-3">
                                        <label for="" class="form-label">স্থান<span class="text-danger">*</span></label>
                                        <input type="text"  name="seminer_place" class="form-control" id="seminer_place0"
                                        placeholder="" >
                                    </div>

                                    <div class="col-lg-6 mb-3">
                                        <label for="" class="form-label">সংখ্যা<span class="text-danger">*</span></label>
                                        <input type="number"  name="seminer_number" class="form-control" id="seminer_number0"
                                        placeholder="" >
                                    </div>

                                    <div class="col-lg-6 mb-3">
                                        <label for="" class="form-label">অংশগ্রহণকারীর সংখ্যা<span class="text-danger">*</span></label>
                                        <input type="number"  name="seminer_perticipantion" class="form-control" id="seminer_perticipantion0"
                                        placeholder="" >
                                    </div>

                                    <div class="col-lg-6 mb-3">
                                        <label for="" class="form-label">বাজেট<span class="text-danger">*</span></label>
                                        <input type="number"  name="seminer_budget" class="form-control" id="seminer_budget0"
                                        placeholder="" >
                                    </div>

                                    <div class="col-lg-12 mb-3">
                                        <label for="" class="form-label">মন্তব্য</label>
                                        <textarea  name="comment" class="form-control" id="comment0"
                                        placeholder="" ></textarea>
                                    </div>

                            </div>
                            <a id="adjoininggModalPost"  class="btn btn-registration">দাখিল করুন</a>

                    </div>
                </div>

            </div>

        </div>
    </div>
</div>

<!-- end modal -->
