<div class="modal modal-xl fade" id="exampleModaleditnew{{ $distributionListOnes->id }}"  aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">

                    বিতরণের জন্য প্রস্তাবিত ত্রাণ সামগ্রীর বিবরণ

                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="card">
                    <div class="card-body" id="viewDistributionEditDataAjax{{ $distributionListOnes->id }}">

                       

                    </div>
                </div>

            </div>

        </div>
    </div>
</div>
