<p>Dear <b>{{ $organization_name }}</b>,</p>
<p> <b>Congratulation</b> – your NGO application has been submitted!  🌟 Thanks for your dedication and effort in making this
    happen. Together, we're stepping closer to realizing our mission and creating a meaningful impact.</p>
<p>Your NGO Registration NO: <b>{{ $token }}</b> <br>
    (When your NGO is officially accepted you will be notified by mail.)</p>

<p>Best regards, <br>
    <b>NGO Affairs Bureau</b> <br>
    Prime Minister's Office <br>
    Plot-E-13/B, Agargaon. Sher-e-Bangla Nagar, Dhaka-1207</p>
